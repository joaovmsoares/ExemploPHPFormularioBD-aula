<?php
$db = new PDO('sqlite:banco.db');

$db->exec("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY, nome TEXT, email TEXT)");

$usuarios = $db->query("SELECT * FROM usuarios");
?>

<html>
<head>
<title>Usuarios</title>
</head>
<body>

<h1>Usuarios</h1>

<?php 
foreach($usuarios as $u){
echo "ID: ".$u['id']."<br>";
echo "Nome: ".$u['nome']."<br>";
echo "Email: ".$u['email']."<br>";
echo "<a href='action.php?acao=excluir&id=".$u['id']."'>Excluir</a>";
echo "<hr>";
}
?>

<h2>Adicionar</h2>

<form action="action.php" method="post">
<input type="hidden" name="acao" value="adicionar">
Nome: <input name="nome"><br>
Email: <input name="email"><br>
<input type="submit" value="Adicionar">
</form>

</body>
</html>
