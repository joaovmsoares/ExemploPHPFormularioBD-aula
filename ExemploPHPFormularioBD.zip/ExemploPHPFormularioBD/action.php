<?php
$db = new PDO('sqlite:banco.db');

$acao = $_REQUEST['acao'];

if($acao == "adicionar"){
$nome = $_POST['nome'];
$email = $_POST['email'];
$db->exec("INSERT INTO usuarios (nome, email) VALUES ('$nome', '$email')");
header("Location: index.php");
}

if($acao == "excluir"){
$id = $_GET['id'];
$db->exec("DELETE FROM usuarios WHERE id = $id");
header("Location: index.php");
}
?>
